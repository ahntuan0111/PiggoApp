/**
 * Appwrite Cloud Function: parse-transaction
 *
 * Architecture: DUAL-ENGINE (Gemini + Groq Fallback) & Keep-Warm
 * CommonJS format — tương thích Appwrite 1.9.0 + Node.js 18
 * Zero npm dependencies
 *
 * Environment Variables required:
 * - GEMINI_API_KEY: Your Google Gemini API Key
 * - GROQ_API_KEY: Your Groq API Key (Dự phòng khi Gemini hết Quota)
 */

const GEMINI_MODEL = 'gemini-3.5-flash';
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

const GROQ_MODEL = 'llama-3.3-70b-versatile';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

module.exports = async ({ req, res, log, error }) => {
  try {
    // ── 0. Bỏ qua Ping Keep-Warm (Tối ưu Cold Start) ─────────────────────────
    let payload = {};
    if (typeof req.body === 'string') {
      try { payload = JSON.parse(req.body); } catch (e) { payload = {}; }
    } else {
      payload = req.body || {};
    }

    if (payload.text === "KEEP_WARM_PING") {
      log("=== KEEP WARM PING RECEIVED - RETURN 200 ===");
      return res.json({ success: true, message: "Warm" }, 200);
    }

    log("=== parse-transaction START ===");

    // ── 1. Kiểm tra API Key ────────────────────────────────────────────────
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      error("[ERROR] Missing GEMINI_API_KEY");
      return res.json({ success: false, message: "Cấu hình server lỗi: thiếu GEMINI_API_KEY" }, 500);
    }

    const text = payload.text;
    const categories = payload.categories || [];
    const currentTime = payload.currentTime || new Date().toISOString();

    log(`[INPUT] text="${text}", categories=[${categories.join(', ')}]`);

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.json({ success: false, message: "Thiếu nội dung văn bản (text)." }, 400);
    }

    // ── 2. Xây dựng prompt (Hỗ trợ đa giao dịch) ──────
    const categoriesStr = categories.join(", ");
    const prompt = `Bạn là hệ thống xử lý ngôn ngữ tự nhiên chuyên bóc tách giao dịch tài chính cá nhân.
Nhiệm vụ của bạn là chuyển đổi câu văn của người dùng thành MỘT MẢNG (ARRAY) các đối tượng JSON chuẩn xác. 
Nếu câu văn chứa nhiều giao dịch (Ví dụ: "Sáng ăn 30k, trưa mua cafe 15k"), bạn PHẢI bóc tách chúng thành nhiều giao dịch riêng biệt.

THÔNG TIN NGỮ CẢNH:
- Thời gian hiện tại của người dùng (mốc để tính toán ngày tháng): ${currentTime}
- Danh sách danh mục (Category) có sẵn: [${categoriesStr}]

QUY TẮC BÓC TÁCH NGHIÊM NGẶT:

1. PHÂN LOẠI GIAO DỊCH (type - BẮT BUỘC):
   - "outflow" (Chi tiêu): Mua, sắm, ăn, uống, trả nợ, chuyển khoản, phí, đóng tiền, "cho mượn"... Mặc định nếu không rõ ràng sẽ là outflow.
   - "inflow" (Thu nhập): Lương, được cho, nhận tiền, bán được, "vay được", "thu nợ"...

2. SỐ TIỀN (amount - BẮT BUỘC là SỐ NGUYÊN dương):
   - "k", "cành", "nghìn" = nhân 1.000 (Vd: 100k = 100000, 50 cành = 50000).
   - "lít", "lốp" = nhân 100.000 (Vd: 2 lít = 200000).
   - "củ", "triệu" = nhân 1.000.000 (Vd: 10 củ = 10000000).
   - Xử lý số thập phân/từ "rưỡi": "1.5 củ" = 1500000, "1 củ rưỡi" = 1500000, "trăm rưỡi" = 150000, "lít rưỡi" = 150000.

3. THỜI GIAN (date - BẮT BUỘC chuẩn ISO 8601):
   - Nếu câu nói có chứa thời gian (vd: "hôm qua", "sáng nay", "tối thứ 2"), bạn PHẢI tự động tính toán ra ngày tháng chính xác dựa trên [Thời gian hiện tại] ở trên.
   - Nếu câu không đề cập thời gian, sử dụng nguyên mốc [Thời gian hiện tại].

4. DANH MỤC (categoryName):
   - Tìm danh mục phù hợp nhất từ [Danh sách danh mục có sẵn].
   - Nếu KHÔNG CÓ danh mục nào thực sự phù hợp, bắt buộc trả về giá trị null. Tuyệt đối không tự bịa ra tên danh mục mới.

5. GHI CHÚ (note):
   - Trích xuất nội dung cốt lõi của giao dịch (vd: "ăn phở", "đổ xăng xe máy", "lương tháng 6").
   - Lược bỏ các từ chỉ số tiền và thời gian.

6. XỬ LÝ LỖI VÀ NGÔN NGỮ (FAULT TOLERANCE):
   - Tự động sửa các lỗi chính tả, ngọng vùng miền hoặc từ đồng âm do AI nhận diện giọng nói (STT) nghe nhầm. 
   - Ví dụ STT nghe nhầm điển hình cần sửa: "chả nợ / trà nợ" -> "trả nợ", "hai nít" -> "hai lít" (200k), "mười cũ" -> "mười củ" (10 triệu), "xì tin" -> "Sting".
   - Người dùng CÓ THỂ nhập Tiếng Việt không dấu (vd: "an sang 30k" = "ăn sáng 30.000"). Bạn phải tự suy luận ngữ cảnh tài chính để hiểu đúng ý nghĩa.

7. ĐA GIAO DỊCH (MULTIPLE TRANSACTIONS):
   - Nhận diện các giao dịch riêng biệt ngay cả khi KHÔNG CÓ dấu phẩy ngăn cách (vd: "ăn sáng 30k mua cafe 15k" -> tách thành 2 giao dịch).
   - Luôn trả về 1 JSON chứa mảng 'transactions', ngay cả khi người dùng chỉ nhập 1 giao dịch.

CÂU CẦN XỬ LÝ: "${text}"`;

    // ── 3. Response Schema (Hỗ trợ Mảng) ─────────────────────────────
    const responseSchema = {
      type: "object",
      properties: {
        transactions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              type: { type: "string", enum: ["inflow", "outflow"], nullable: false },
              amount: { type: "integer", nullable: false },
              categoryName: { type: "string", nullable: true },
              note: { type: "string", nullable: true },
              date: { type: "string", nullable: false },
            },
            required: ["type", "amount", "date"],
          }
        }
      },
      required: ["transactions"],
    };

    let parsedData = null;

    // ── 4. ENGINE 1: Thử gọi Google Gemini trước ───────────────────────────
    try {
      const requestBody = {
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: responseSchema,
        },
      };

      log(`[GEMINI] Calling ${GEMINI_MODEL}...`);
      const geminiResponse = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      const geminiJson = await geminiResponse.json();

      if (!geminiResponse.ok) {
        const apiError = geminiJson?.error?.message || `Gemini HTTP ${geminiResponse.status}`;
        throw new Error(`Gemini API: ${apiError}`);
      }

      const candidate = geminiJson?.candidates?.[0];
      if (!candidate) throw new Error("Gemini không trả về candidates.");

      const rawText = candidate?.content?.parts?.[0]?.text || "";
      const cleanedText = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleanedText);
      log(`[GEMINI SUCCESS]`);

    } catch (geminiErr) {
      error(`[GEMINI FAILED] ${geminiErr.message}`);

      const errMsg = geminiErr.message.toLowerCase();
      // Bắt các keyword lỗi liên quan đến Rate Limit, Quota, Too Many Requests
      const isQuotaOrRateLimit = errMsg.includes('quota') || errMsg.includes('429') || errMsg.includes('too many requests') || errMsg.includes('exceeded');

      const groqApiKey = process.env.GROQ_API_KEY;

      // ── 5. ENGINE 2 (FALLBACK): Nếu lỗi Quota & có cài Groq Key ───────────
      if (isQuotaOrRateLimit && groqApiKey) {
        log(`[FALLBACK] Đang chuyển hướng sang GroqCloud (${GROQ_MODEL})...`);

        try {
          // Gắn thêm yêu cầu output JSON sát sao cho Llama 3 (bổ sung phía sau prompt gốc)
          const groqPrompt = prompt + `\n\nBẮT BUỘC trả về ĐÚNG cấu trúc JSON sau (chỉ JSON, không markdown, không giải thích):\n` + JSON.stringify(responseSchema);

          const groqResponse = await fetch(GROQ_API_URL, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${groqApiKey}`
            },
            body: JSON.stringify({
              model: GROQ_MODEL,
              messages: [{ role: 'user', content: groqPrompt }],
              response_format: { type: "json_object" }, // Bật native JSON mode của Groq
              temperature: 0.1 // Nhiệt độ thấp để xuất JSON ổn định hơn
            })
          });

          const groqJson = await groqResponse.json();
          if (!groqResponse.ok) {
            throw new Error(`Groq HTTP ${groqResponse.status}: ${groqJson?.error?.message}`);
          }

          const rawText = groqJson.choices?.[0]?.message?.content || "";
          log(`[GROQ RAW TEXT] ${rawText}`);
          const cleanedText = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();
          parsedData = JSON.parse(cleanedText);
          log(`[GROQ SUCCESS]`);

        } catch (groqErr) {
          error(`[GROQ FAILED] ${groqErr.message}`);
          // Nếu cả 2 đều sập, quăng lỗi tổng hợp ra cho Flutter App hiển thị Toast thân thiện
          throw new Error(`Hệ thống AI đang tạm thời quá tải. Vui lòng thử lại sau. (Gemini: Hết hạn mức, Groq: Lỗi phụ)`);
        }
      } else {
        // Nếu lỗi không phải do Quota (mà do syntax, sập mạng Google...) hoặc chưa có GROQ_API_KEY
        // Sẽ quăng lỗi gốc để bạn tiện fix bug
        throw geminiErr;
      }
    }

    // ── 6. Trả về kết quả cuối cùng cho Appwrite ───────────────────────────
    if (!parsedData || !Array.isArray(parsedData.transactions)) {
      throw new Error("Không thể parse dữ liệu JSON từ AI hoặc định dạng không đúng (thiếu mảng transactions).");
    }

    log(`[OK] Đã bóc tách thành công ${parsedData.transactions.length} giao dịch.`);
    log("=== parse-transaction SUCCESS ===");

    return res.json({ success: true, data: parsedData });

  } catch (err) {
    error(`[EXCEPTION] ${err.message}`);
    error(`[STACK] ${err.stack}`);
    return res.json({ success: false, message: err.message }, 500);
  }
};
