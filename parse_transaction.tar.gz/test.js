import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: "AQ.Ab8RN6L0vhPV1qA2bDM65maY316Aw6mJZzzjOuMgPURfoGyjMg" });

async function run() {
    try {
        const result = await ai.models.generateContent({
            model: 'gemini-3.5-flash',
            contents: 'say hello and output a JSON {"msg": "hello"}',
            config: {
                responseMimeType: "application/json",
            }
        });
        console.log("result.text:", result.text);
        console.log("JSON.parse:", JSON.parse(result.text));
    } catch(err) {
        console.error(err);
    }
}
run();
